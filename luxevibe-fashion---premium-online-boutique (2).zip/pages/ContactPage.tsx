
import React from 'react';
import { Mail, Phone, MapPin, ArrowRight, Instagram } from 'lucide-react';
import { Link } from 'react-router-dom';

const ContactPage: React.FC = () => {
  return (
    <div className="pb-40">
      <div className="bg-white border-b border-gray-50">
        <div className="max-w-[1400px] mx-auto px-4 py-24">
          <h1 className="text-7xl font-black serif tracking-tighter mb-6">Contact Us</h1>
          <p className="text-2xl text-gray-400 font-light italic serif">We're here to elevate your experience.</p>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 mt-24">
        <div className="grid lg:grid-cols-12 gap-24">
          
          {/* Contact Form */}
          <div className="lg:col-span-7 space-y-16">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold uppercase tracking-tighter">Send a Message</h2>
              <p className="text-gray-500 font-light">Whether you have a question about a fit, a return, or just want to say hi, fill out the form below and we'll get back to you within 24 hours.</p>
            </div>

            <form className="grid md:grid-cols-2 gap-10">
              <div className="space-y-2 border-b-2 border-gray-100 pb-2 focus-within:border-black transition duration-500">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Full Name</label>
                <input type="text" className="w-full bg-transparent border-none outline-none text-sm font-bold uppercase tracking-widest px-0 focus:ring-0" placeholder="ENTER NAME" />
              </div>
              <div className="space-y-2 border-b-2 border-gray-100 pb-2 focus-within:border-black transition duration-500">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Email Address</label>
                <input type="email" className="w-full bg-transparent border-none outline-none text-sm font-bold uppercase tracking-widest px-0 focus:ring-0" placeholder="EMAIL@EXAMPLE.COM" />
              </div>
              <div className="md:col-span-2 space-y-2 border-b-2 border-gray-100 pb-2 focus-within:border-black transition duration-500">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Subject</label>
                <select className="w-full bg-transparent border-none outline-none text-sm font-bold uppercase tracking-widest px-0 focus:ring-0 cursor-pointer">
                  <option>Order Status</option>
                  <option>Product Inquiries</option>
                  <option>Returns & Exchanges</option>
                  <option>Press & Collaboration</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="md:col-span-2 space-y-2 border-b-2 border-gray-100 pb-2 focus-within:border-black transition duration-500">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Message</label>
                <textarea className="w-full bg-transparent border-none outline-none text-sm font-medium leading-relaxed px-0 focus:ring-0 min-h-[150px] resize-none" placeholder="HOW CAN WE HELP?"></textarea>
              </div>
              
              <button type="submit" className="md:col-span-2 bg-black text-white py-6 uppercase text-[11px] font-black tracking-[0.4em] hover:bg-pink-600 transition duration-500 shadow-2xl flex items-center justify-center gap-4">
                Send Inquiry <ArrowRight size={16} />
              </button>
            </form>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-5 space-y-20">
            <div className="space-y-12">
               <div className="space-y-6">
                 <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-pink-600">Client Support</h4>
                 <div className="space-y-4">
                   <a href="mailto:support@luxevibe.com" className="flex items-center gap-4 text-xl font-bold serif group">
                     <Mail size={20} className="text-gray-300 group-hover:text-pink-600 transition" />
                     support@luxevibe.com
                   </a>
                   <a href="tel:18005550199" className="flex items-center gap-4 text-xl font-bold serif group">
                     <Phone size={20} className="text-gray-300 group-hover:text-pink-600 transition" />
                     +1 (800) LUXE-VIBE
                   </a>
                 </div>
               </div>

               <div className="space-y-6">
                 <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-pink-600">Global Headquarters</h4>
                 <div className="flex gap-4 group">
                   <MapPin size={20} className="text-gray-300 group-hover:text-pink-600 transition shrink-0" />
                   <div>
                     <p className="text-xl font-bold serif">The LA Showroom</p>
                     <p className="text-gray-500 font-light mt-2 leading-relaxed">
                       8800 Sunset Blvd, Suite 400<br />
                       West Hollywood, CA 90069
                     </p>
                   </div>
                 </div>
               </div>

               <div className="space-y-6">
                 <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-pink-600">Press & Social</h4>
                 <div className="flex gap-4">
                   <a href="#" className="w-12 h-12 rounded-full border border-gray-100 flex items-center justify-center hover:bg-black hover:text-white transition duration-500"><Instagram size={20} /></a>
                   <div className="flex flex-col justify-center">
                     <p className="text-xs font-bold uppercase tracking-widest">@LuxeVibeSociety</p>
                     <p className="text-[10px] text-gray-400 font-medium uppercase tracking-widest">Tag us to be featured</p>
                   </div>
                 </div>
               </div>
            </div>

            <div className="bg-gray-50 p-12 space-y-6 rounded-sm border border-gray-100 shadow-inner">
               <h5 className="text-[11px] font-black uppercase tracking-[0.3em]">Hours of Curation</h5>
               <ul className="text-[12px] space-y-3 font-medium text-gray-500 uppercase tracking-widest">
                 <li className="flex justify-between border-b border-gray-200/50 pb-2"><span className="text-black">Mon — Fri</span> <span>9AM — 8PM PST</span></li>
                 <li className="flex justify-between border-b border-gray-200/50 pb-2"><span className="text-black">Saturday</span> <span>10AM — 6PM PST</span></li>
                 <li className="flex justify-between border-b border-gray-200/50 pb-2"><span className="text-black">Sunday</span> <span>12PM — 5PM PST</span></li>
               </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
