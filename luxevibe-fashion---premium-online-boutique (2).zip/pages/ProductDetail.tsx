
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Truck, RefreshCcw, ShieldCheck, ChevronDown, Sparkles, Plus, Minus, Share2, Heart, ChevronRight, Tag, Clock } from 'lucide-react';
import { PRODUCTS, MOCK_REVIEWS } from '../constants';
import { getStylingAdvice } from '../services/geminiService';
import { CartItem, Product } from '../types';
import ProductCard from '../components/ProductCard';

interface ProductDetailProps {
  onAddToCart: (item: CartItem) => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ onAddToCart }) => {
  const { id } = useParams();
  const product = PRODUCTS.find(p => p.id === id);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<string | null>('details');

  useEffect(() => {
    if (product) {
      setSelectedColor(product.colors[0]);
    }
    window.scrollTo(0, 0);
  }, [product, id]);

  const handleAiStylist = async () => {
    if (!product) return;
    setLoadingAi(true);
    const advice = await getStylingAdvice(product.name, product.category);
    setAiAdvice(advice);
    setLoadingAi(false);
  };

  if (!product) return <div className="p-40 text-center serif text-3xl italic">Refining our selection...</div>;

  const toggleAccordion = (id: string) => {
    setOpenAccordion(openAccordion === id ? null : id);
  };

  const completeTheLookItems = PRODUCTS.filter(p => product.completeLookIds?.includes(p.id));

  // Dynamic Dates
  const today = new Date();
  const arrivalDate = new Date(today.setDate(today.getDate() + 2)).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <div className="max-w-[1400px] mx-auto px-4 py-8 md:py-16">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-12 border-b border-gray-50 pb-4">
        <Link to="/" className="hover:text-black transition">Home</Link>
        <ChevronRight size={10} />
        <Link to={`/listing?cat=${product.category}`} className="hover:text-black transition">{product.category}</Link>
        <ChevronRight size={10} />
        <span className="text-black">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        
        {/* Gallery - High Res Multi-Grid Style */}
        <div className="lg:col-span-7 flex flex-col md:flex-row gap-6">
          <div className="hidden md:flex flex-col gap-4 w-24">
            {product.images.map((img, i) => (
              <button 
                key={i} 
                className={`relative aspect-[3/4] overflow-hidden border transition duration-300 ${activeImage === i ? 'border-black' : 'border-transparent opacity-60 hover:opacity-100'}`}
                onClick={() => setActiveImage(i)}
              >
                <img src={img} className="w-full h-full object-cover" alt="" />
              </button>
            ))}
          </div>
          <div className="flex-1 bg-gray-50 relative aspect-[3/4] overflow-hidden group">
            <img 
              src={product.images[activeImage] || product.images[0]} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-6 left-6 flex items-center gap-3 bg-white/80 backdrop-blur-sm px-4 py-2 text-[9px] font-bold uppercase tracking-widest border border-gray-100">
              <Clock size={12} className="text-pink-600" /> Free 2-Day Shipping
            </div>
          </div>
        </div>

        {/* Info - Clean Revolve Sidebar */}
        <div className="lg:col-span-5 space-y-12">
          <div>
            <div className="flex justify-between items-start">
              <Link to={`/listing?brand=${product.brand}`} className="text-[12px] font-black uppercase tracking-[0.4em] text-black hover:text-pink-600 transition mb-4 block underline underline-offset-8 decoration-gray-200 decoration-2">
                {product.brand}
              </Link>
            </div>
            <h1 className="text-3xl font-bold uppercase tracking-tight text-gray-900 mb-6">{product.name}</h1>
            <div className="flex items-center justify-between border-y border-gray-100 py-8">
              <div className="flex items-baseline gap-4">
                <span className="text-3xl font-bold text-black tracking-tighter">${product.price}</span>
                {product.originalPrice && <span className="text-lg text-gray-300 line-through">${product.originalPrice}</span>}
              </div>
              <div className="text-right">
                <div className="flex items-center justify-end text-black mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={12} fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'} />
                  ))}
                </div>
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em]">{product.reviewsCount} REVIEWS</span>
              </div>
            </div>
          </div>

          {/* Revolve Bundle Promo */}
          <div className="bg-pink-50 border border-pink-100 p-6 flex items-start gap-4 animate-pulse">
            <Tag size={20} className="text-pink-600 shrink-0" />
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-pink-700">Multi-Buy Exclusive Deal</p>
              <p className="text-[11px] text-pink-600 leading-relaxed font-medium mt-1">Add one more item to your bag and automatically save 15% on your entire order.</p>
            </div>
          </div>

          <div className="space-y-10">
            {/* Color Selection */}
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 mb-5">Color: <span className="text-black">{selectedColor}</span></p>
              <div className="flex gap-4">
                {product.colors.map(color => (
                  <button 
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`group relative w-12 h-12 rounded-full border transition-all p-0.5 ${selectedColor === color ? 'border-black ring-1 ring-black ring-offset-4' : 'border-transparent hover:border-gray-200'}`}
                  >
                    <div className="w-full h-full rounded-full bg-gray-200" style={{ backgroundColor: color.toLowerCase() }} />
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div>
              <div className="flex justify-between items-center mb-5">
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400">Size: <span className="text-black">{selectedSize || 'Select Size'}</span></p>
                <button className="text-[10px] font-bold uppercase tracking-widest underline decoration-gray-200 hover:text-black transition">Size Guide</button>
              </div>
              <div className="grid grid-cols-5 gap-3">
                {product.sizes.map(size => (
                  <button 
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`py-5 text-[11px] font-bold uppercase transition-all border ${selectedSize === size ? 'bg-black text-white border-black shadow-lg' : 'bg-white border-gray-100 hover:border-black'}`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* CTA & Delivery Estimate */}
            <div className="space-y-6">
              <button 
                onClick={() => onAddToCart({ product, quantity: 1, selectedSize, selectedColor })}
                disabled={!selectedSize}
                className={`w-full py-6 text-[11px] font-bold uppercase tracking-[0.3em] transition-all shadow-xl ${selectedSize ? 'bg-black text-white hover:bg-gray-800' : 'bg-gray-100 text-gray-300 cursor-not-allowed'}`}
              >
                {selectedSize ? 'Add to Bag' : 'Select a Size'}
              </button>
              
              <div className="flex items-center justify-center gap-6 py-4 border-t border-gray-50">
                <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">
                  <Truck size={14} className="text-black"/> 
                  <span>Estimated Arrival: <span className="text-black">{arrivalDate}</span></span>
                </div>
              </div>
            </div>
          </div>

          {/* Tabbed Info - Revolve Classic Style */}
          <div className="border-t border-gray-100 pt-8 space-y-8">
            <div className="flex gap-8 text-[11px] font-black uppercase tracking-widest border-b border-gray-50 pb-4 overflow-x-auto scrollbar-hide">
              <button onClick={() => setOpenAccordion('details')} className={`whitespace-nowrap ${openAccordion === 'details' ? 'text-black border-b-2 border-black' : 'text-gray-300'}`}>Details</button>
              <button onClick={() => setOpenAccordion('fit')} className={`whitespace-nowrap ${openAccordion === 'fit' ? 'text-black border-b-2 border-black' : 'text-gray-300'}`}>Size & Fit</button>
              <button onClick={() => setOpenAccordion('brand')} className={`whitespace-nowrap ${openAccordion === 'brand' ? 'text-black border-b-2 border-black' : 'text-gray-300'}`}>The Brand</button>
              <button onClick={() => setOpenAccordion('shipping')} className={`whitespace-nowrap ${openAccordion === 'shipping' ? 'text-black border-b-2 border-black' : 'text-gray-300'}`}>Shipping</button>
            </div>

            <div className="text-[12px] leading-relaxed text-gray-600 animate-in fade-in slide-in-from-top-2">
              {openAccordion === 'details' && (
                <div className="space-y-6">
                   <p>{product.description}</p>
                   <ul className="grid grid-cols-2 gap-y-4 font-bold text-black uppercase tracking-tighter">
                     <li>Material: <span className="text-gray-400 ml-1">{product.material}</span></li>
                     <li>Care: <span className="text-gray-400 ml-1">{product.care}</span></li>
                     <li>Category: <span className="text-gray-400 ml-1">{product.category}</span></li>
                     <li>Season: <span className="text-gray-400 ml-1">SS24</span></li>
                   </ul>
                </div>
              )}
              {openAccordion === 'fit' && (
                <div className="space-y-6">
                  <div className="bg-gray-50 p-6 space-y-4 border border-gray-100">
                    <p className="font-black text-black uppercase tracking-widest">{product.modelInfo}</p>
                    <div className="grid grid-cols-4 gap-4 text-[10px] uppercase font-bold text-gray-400">
                      <div>HT: <span className="text-black">{product.modelSpecs?.height}</span></div>
                      <div>W: <span className="text-black">{product.modelSpecs?.waist}</span></div>
                      <div>B: <span className="text-black">{product.modelSpecs?.bust}</span></div>
                      <div>H: <span className="text-black">{product.modelSpecs?.hips}</span></div>
                    </div>
                  </div>
                  <p className="italic">{product.fitNotes}</p>
                </div>
              )}
              {openAccordion === 'brand' && (
                <div className="space-y-4">
                  <h4 className="font-black text-black uppercase tracking-[0.2em]">{product.brand}</h4>
                  <p>Born in the heart of Los Angeles, {product.brand} defines contemporary feminine luxury. Each piece is designed for the modern woman who refuses to compromise on quality or style.</p>
                  <button className="text-[10px] font-black uppercase tracking-widest underline text-black">View All From {product.brand}</button>
                </div>
              )}
              {openAccordion === 'shipping' && (
                <p>Enjoy complimentary 2-day shipping on all domestic orders. We also offer easy 30-day returns with free return labels. International orders are shipped via DHL Express for arrival in 3-5 business days.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Revolve Review Style: Rich Body Metrics */}
      <section className="mt-40 pt-40 border-t border-gray-100">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-12 gap-20">
            <div className="md:col-span-4 space-y-12">
              <h2 className="text-4xl font-bold uppercase tracking-tighter">Verified Fit Feed</h2>
              <div className="space-y-6 bg-gray-50 p-10 border border-gray-100">
                <div className="text-6xl font-bold tracking-tighter">{product.rating}</div>
                <div className="flex text-black">
                  {[...Array(5)].map((_, i) => <Star key={i} size={16} fill={i < 4 ? 'currentColor' : 'none'} />)}
                </div>
                <p className="text-[10px] text-gray-500 font-black uppercase tracking-[0.3em]">{product.reviewsCount} CUSTOMER REVIEWS</p>
                <button className="w-full py-5 bg-black text-white text-[10px] font-black uppercase tracking-[0.3em] hover:bg-pink-600 transition shadow-2xl">Review This Product</button>
              </div>
            </div>
            
            <div className="md:col-span-8 space-y-20">
              {MOCK_REVIEWS.map(review => (
                <div key={review.id} className="group border-b border-gray-100 pb-20 last:border-0">
                  <div className="flex flex-col lg:flex-row gap-10 items-start">
                    {/* User Profile Info */}
                    <div className="lg:w-1/3 space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center font-bold text-sm tracking-tighter">
                          {review.userName.charAt(0)}
                        </div>
                        <div>
                          <p className="text-xs font-black uppercase tracking-widest">{review.userName}</p>
                          <span className="text-[9px] text-gray-400 font-bold uppercase tracking-widest">Verified Fashionista</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 bg-gray-50 p-4 border border-gray-100">
                        <div className="border-r border-gray-200">HT: <span className="text-black">{review.userHeight}</span></div>
                        <div>WT: <span className="text-black">{review.userWeight}</span></div>
                        <div className="border-r border-gray-200">SIZE: <span className="text-pink-600">{review.sizePurchased}</span></div>
                        <div>RATING: <span className="text-black">{review.rating}/5</span></div>
                      </div>
                    </div>
                    
                    {/* Comment Area */}
                    <div className="flex-1">
                      <p className="text-lg text-gray-800 leading-relaxed font-light italic serif mb-8">"{review.comment}"</p>
                      <div className="flex items-center justify-between">
                         <span className="text-[10px] text-gray-300 font-bold uppercase tracking-widest">{review.date}</span>
                         <div className="flex gap-6">
                            <button className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-black transition flex items-center gap-2">Helpful (24)</button>
                            <button className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-black transition">Report</button>
                         </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <button className="w-full py-10 text-[10px] font-black uppercase tracking-[0.4em] text-gray-300 hover:text-black transition-all border-y border-gray-50 bg-gray-50/30">Expand Fit Feed</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProductDetail;
