
import React from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { PRODUCTS } from '../constants';
import { ArrowRight, Instagram, ShoppingBag } from 'lucide-react';

const Home: React.FC = () => {
  const featured = PRODUCTS.slice(0, 4);
  const newArrivals = PRODUCTS.filter(p => p.isNew).slice(0, 4);

  return (
    <div className="space-y-24 pb-20">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <video 
          autoPlay 
          muted 
          loop 
          className="absolute inset-0 w-full h-full object-cover opacity-90"
          poster="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=2070"
        >
          <source src="https://assets.mixkit.co/videos/preview/mixkit-fashion-model-showing-a-light-blue-dress-34407-large.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative text-center text-white px-4">
          <span className="uppercase tracking-[0.4em] text-xs mb-6 block font-medium animate-pulse">Spring / Summer 2024</span>
          <h1 className="text-6xl md:text-9xl font-bold mb-10 serif leading-none">The Radiant<br/>Collection</h1>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              to="/listing" 
              className="bg-white text-black px-12 py-5 text-xs font-bold uppercase tracking-widest hover:bg-black hover:text-white transition-all duration-300"
            >
              Shop New Arrivals
            </Link>
            <Link 
              to="/listing?cat=Dresses" 
              className="bg-transparent border border-white text-white px-12 py-5 text-xs font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all duration-300 backdrop-blur-sm"
            >
              Explore Dresses
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
        {[
          { title: 'Free Express Shipping', desc: 'On orders over $100', icon: 'Truck' },
          { title: '24/7 Styling Help', desc: 'Chat with our AI experts', icon: 'Sparkles' },
          { title: 'Global Returns', desc: 'Easy 30-day window', icon: 'Refresh' },
          { title: 'Points for Shopping', desc: 'Join Vibe Rewards', icon: 'Star' }
        ].map((badge, idx) => (
          <div key={idx} className="text-center group cursor-default">
            <h3 className="text-sm font-bold uppercase tracking-widest mb-1 group-hover:text-pink-600 transition-colors">{badge.title}</h3>
            <p className="text-[11px] text-gray-400 uppercase tracking-tighter">{badge.desc}</p>
          </div>
        ))}
      </section>

      {/* Shop by Category */}
      <section className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold serif mb-10 text-center uppercase tracking-widest">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { name: 'Dresses', img: 'https://images.unsplash.com/photo-1539008835270-1284f6707324?auto=format&fit=crop&w=600' },
            { name: 'Tops', img: 'https://images.unsplash.com/photo-1564584217132-2271feaeb3c5?auto=format&fit=crop&w=600' },
            { name: 'Bottoms', img: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=600' },
            { name: 'Accessories', img: 'https://images.unsplash.com/photo-1611085583191-a3b1a30a5a4a?auto=format&fit=crop&w=600' }
          ].map(cat => (
            <Link key={cat.name} to={`/listing?cat=${cat.name}`} className="relative aspect-[4/5] overflow-hidden group">
              <img src={cat.img} alt={cat.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-700" />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                <span className="text-white text-xl font-bold serif uppercase tracking-widest">{cat.name}</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Trending Section */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-end mb-12 border-b border-gray-100 pb-6">
          <div>
            <span className="text-[10px] uppercase tracking-widest text-pink-600 font-bold mb-2 block">Curation</span>
            <h2 className="text-4xl font-bold serif">Trending This Week</h2>
          </div>
          <Link to="/listing" className="group flex items-center gap-2 text-xs font-bold uppercase tracking-widest border-b-2 border-black pb-1 hover:text-pink-600 hover:border-pink-600 transition-all">
            View All Trending <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-16">
          {featured.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Editorial Content */}
      <section className="bg-gray-50 py-24">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-16 items-center">
          <div className="relative aspect-[3/4] overflow-hidden">
            <img src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" alt="Model" />
            <div className="absolute bottom-8 left-8 bg-white p-6 shadow-xl max-w-xs">
              <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Editor's Note</p>
              <h4 className="text-xl serif italic font-bold">"Minimalism is about the perfect cut, not just the absence of detail."</h4>
            </div>
          </div>
          <div className="space-y-8">
            <h2 className="text-5xl font-bold serif leading-tight uppercase">Sustainable<br/>Sophistication</h2>
            <p className="text-gray-600 leading-relaxed text-lg">Discover our curated selection of brands committed to conscious manufacturing and timeless design. Style that looks good and does good.</p>
            <Link to="/listing" className="inline-flex items-center gap-4 bg-black text-white px-10 py-4 uppercase text-xs font-bold tracking-[0.2em] hover:bg-pink-600 transition-colors">
              Read the Edit
            </Link>
          </div>
        </div>
      </section>

      {/* Social Feed */}
      <section className="max-w-7xl mx-auto px-4 pb-12">
        <div className="text-center mb-16 space-y-4">
          <Instagram size={32} className="mx-auto text-pink-600" />
          <h2 className="text-4xl font-bold serif">#LuxeVibeSociety</h2>
          <p className="text-gray-500 uppercase tracking-widest text-xs">Share your look for a chance to be featured</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="relative aspect-square overflow-hidden group cursor-pointer">
              <img src={`https://picsum.photos/seed/fashion${i}/400/400`} className="w-full h-full object-cover group-hover:scale-110 transition duration-500" alt="Social post" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <ShoppingBag size={24} className="text-white" />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
