
import React, { useState } from 'react';
import { Package, Search, Truck, MapPin, CheckCircle, ChevronRight, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const TrackOrderPage: React.FC = () => {
  const [orderId, setOrderId] = useState('');
  const [email, setEmail] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [trackingResult, setTrackingResult] = useState<any>(null);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    // Simulate API call
    setTimeout(() => {
      setTrackingResult({
        status: 'In Transit',
        eta: 'Oct 28, 2024',
        location: 'West Hollywood Distribution Center',
        steps: [
          { date: 'Oct 25, 2:30 PM', desc: 'Order Placed', completed: true },
          { date: 'Oct 26, 9:00 AM', desc: 'Order Processed', completed: true },
          { date: 'Oct 26, 4:15 PM', desc: 'Shipped via Express Delivery', completed: true },
          { date: 'Oct 27, 8:00 AM', desc: 'Arrived at Local Sort Facility', completed: false }
        ]
      });
      setIsSearching(false);
    }, 1500);
  };

  return (
    <div className="pb-40">
      <div className="bg-white border-b border-gray-50">
        <div className="max-w-[1400px] mx-auto px-4 py-24">
          <h1 className="text-7xl font-black serif tracking-tighter mb-6">Track Order</h1>
          <p className="text-2xl text-gray-400 font-light italic serif">The journey to your doorstep.</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 mt-24">
        {!trackingResult ? (
          <div className="bg-white border border-gray-100 p-12 md:p-20 shadow-2xl space-y-16 animate-in zoom-in-95 duration-700">
            <div className="text-center space-y-4">
               <Package size={48} className="mx-auto text-pink-600 mb-6" />
               <h2 className="text-3xl font-bold uppercase tracking-tight">Enter Your Details</h2>
               <p className="text-gray-500 font-light">Retrieve your order status using your order number and email address found in your confirmation email.</p>
            </div>

            <form onSubmit={handleTrack} className="space-y-10">
              <div className="grid md:grid-cols-2 gap-10">
                <div className="space-y-2 border-b-2 border-gray-100 pb-2 focus-within:border-black transition duration-500">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Order Number</label>
                  <input 
                    type="text" 
                    required
                    value={orderId}
                    onChange={(e) => setOrderId(e.target.value)}
                    className="w-full bg-transparent border-none outline-none text-sm font-bold uppercase tracking-widest px-0 focus:ring-0" 
                    placeholder="LV-XXXXXXXX" 
                  />
                </div>
                <div className="space-y-2 border-b-2 border-gray-100 pb-2 focus-within:border-black transition duration-500">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Email Address</label>
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-transparent border-none outline-none text-sm font-bold uppercase tracking-widest px-0 focus:ring-0" 
                    placeholder="EMAIL@EXAMPLE.COM" 
                  />
                </div>
              </div>
              
              <button 
                type="submit" 
                disabled={isSearching}
                className="w-full bg-black text-white py-6 uppercase text-[11px] font-black tracking-[0.4em] hover:bg-pink-600 transition duration-500 shadow-2xl flex items-center justify-center gap-4 disabled:bg-gray-100 disabled:text-gray-300"
              >
                {isSearching ? 'Retrieving Status...' : (
                  <>Track Order <ArrowRight size={16} /></>
                )}
              </button>
            </form>
          </div>
        ) : (
          <div className="space-y-12 animate-in fade-in slide-in-from-bottom-6 duration-700">
             <button onClick={() => setTrackingResult(null)} className="text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:text-black flex items-center gap-2 transition">
               <ArrowRight size={14} className="rotate-180" /> Track Another Order
             </button>

             <div className="bg-black text-white p-12 md:p-20 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-pink-600/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
                
                <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
                  <div className="space-y-4">
                    <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-pink-500">Current Status</h4>
                    <h3 className="text-5xl font-bold serif italic">{trackingResult.status}</h3>
                    <p className="text-gray-400 flex items-center gap-2 uppercase text-[10px] tracking-widest font-bold">
                      <MapPin size={12}/> {trackingResult.location}
                    </p>
                  </div>
                  <div className="text-right space-y-2">
                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-500">Estimated Arrival</p>
                    <p className="text-3xl font-black serif text-white">{trackingResult.eta}</p>
                  </div>
                </div>

                <div className="mt-20 space-y-12 relative">
                   <div className="absolute left-6 top-2 bottom-2 w-px bg-gray-800" />
                   {trackingResult.steps.map((step: any, i: number) => (
                     <div key={i} className={`flex gap-10 items-start relative z-10 transition-opacity duration-1000 ${step.completed ? 'opacity-100' : 'opacity-30'}`}>
                       <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 border-4 border-black ${step.completed ? 'bg-pink-600' : 'bg-gray-900'}`}>
                          {step.completed ? <CheckCircle size={16} /> : <div className="w-2 h-2 rounded-full bg-gray-600" />}
                       </div>
                       <div>
                         <p className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1">{step.date}</p>
                         <p className={`text-xl font-bold serif ${step.completed ? 'text-white' : 'text-gray-600'}`}>{step.desc}</p>
                       </div>
                     </div>
                   ))}
                </div>
             </div>

             <div className="grid md:grid-cols-2 gap-8">
                <div className="p-10 border border-gray-100 flex items-center gap-6 group hover:border-black transition">
                   <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center group-hover:bg-black group-hover:text-white transition duration-500">
                      <Truck size={24} />
                   </div>
                   <div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Carrier</p>
                      <p className="text-lg font-bold serif">LuxeExpress Prime</p>
                   </div>
                </div>
                <div className="p-10 border border-gray-100 flex items-center gap-6 group hover:border-black transition">
                   <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center group-hover:bg-black group-hover:text-white transition duration-500">
                      <Package size={24} />
                   </div>
                   <div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Package Type</p>
                      <p className="text-lg font-bold serif">Signature Eco-Crate</p>
                   </div>
                </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TrackOrderPage;
