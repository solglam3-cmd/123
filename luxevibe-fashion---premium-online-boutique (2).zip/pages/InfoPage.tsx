
import React, { useEffect } from 'react';
import { ChevronRight, ArrowRight, ShieldCheck, Truck, Sparkles, Heart } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

interface InfoPageProps {
  type: 'story' | 'sustainability' | 'careers' | 'privacy' | 'terms' | 'shipping' | 'returns' | 'faq';
}

const InfoPage: React.FC<InfoPageProps> = ({ type }) => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  const contentMap = {
    story: {
      title: 'Our Story',
      subtitle: 'Curation with a point of view.',
      hero: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?auto=format&fit=crop&q=80&w=2070',
      body: (
        <div className="space-y-16">
          <section className="space-y-8">
            <h3 className="text-4xl font-bold serif tracking-tight">Founded in 2024, LuxeVibe was born from a simple desire: to make high-end curation accessible to the modern visionary.</h3>
            <p className="text-lg text-gray-600 leading-relaxed font-light">Based in the heart of Los Angeles, we began as a small group of designers and tech enthusiasts who believed that shopping should be as inspiring as the fashion itself. We didn't want to just sell clothes; we wanted to provide a lifestyle.</p>
          </section>
          
          <div className="grid md:grid-cols-2 gap-12">
            <img src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800" className="w-full aspect-square object-cover grayscale" alt="" />
            <div className="flex flex-col justify-center space-y-6">
              <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-pink-600">The Curation</h4>
              <p className="text-gray-600 leading-relaxed">Every piece on LuxeVibe is hand-selected by our editorial team. We partner with emerging designers and established fashion houses to bring you a blend of timeless classics and experimental trends that you won't find anywhere else.</p>
              <p className="text-gray-600 leading-relaxed">Our buyers travel globally—from the streets of Paris to the studios of Seoul—to ensure our vault remains the most forward-thinking collection in the industry.</p>
            </div>
          </div>

          <section className="bg-black text-white p-12 md:p-24 space-y-8 text-center">
            <Sparkles size={40} className="mx-auto text-pink-500 mb-4" />
            <h2 className="text-5xl font-bold serif italic">"Fashion is the armor to survive the reality of everyday life."</h2>
            <p className="text-gray-400 uppercase tracking-widest text-[11px] font-bold">— Bill Cunningham</p>
          </section>
        </div>
      )
    },
    sustainability: {
      title: 'Conscious Vibe',
      subtitle: 'Our commitment to a beautiful future.',
      hero: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=2013',
      body: (
        <div className="space-y-20">
          <div className="max-w-3xl space-y-8">
            <h3 className="text-4xl font-bold serif">Luxury shouldn't cost the Earth. We are reimagining every step of the fashion journey.</h3>
            <p className="text-lg text-gray-600 font-light leading-relaxed">Sustainability isn't a trend for us; it's a foundational pillar. By 2026, we aim for 80% of our catalog to be certified eco-friendly or made from recycled materials.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            {[
              { title: 'Ethical Sourcing', desc: 'We only partner with manufacturers who provide living wages and safe working conditions. Our audit process is transparent and relentless.' },
              { title: 'Zero-Waste Packaging', desc: 'All LuxeVibe orders are shipped in 100% compostable mailers with FSC-certified recycled paper inserts and soy-based inks.' },
              { title: 'Carbon Neutrality', desc: 'We offset the carbon footprint of every delivery through a partnership with global reforestation projects.' }
            ].map(item => (
              <div key={item.title} className="space-y-6">
                <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center text-green-600">
                  <ShieldCheck size={24} />
                </div>
                <h4 className="text-xl font-bold uppercase tracking-tight">{item.title}</h4>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          <section className="bg-gray-50 p-16 space-y-8 text-center">
            <h2 className="text-3xl font-bold serif">The Circular Wardrobe</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">Explore our new 'Pre-Loved' collection launching this Fall. We believe the life of a luxury garment should never truly end.</p>
            <button className="text-[10px] font-bold uppercase tracking-[0.3em] border-b-2 border-black pb-1">Learn About Recycling</button>
          </section>
        </div>
      )
    },
    shipping: {
      title: 'Shipping Info',
      subtitle: 'Fast, secure, and globally connected.',
      hero: 'https://images.unsplash.com/photo-1566576721346-d4a3b4eaad5b?auto=format&fit=crop&q=80&w=1974',
      body: (
        <div className="space-y-16">
          <div className="grid md:grid-cols-2 gap-20">
            <div className="space-y-10">
              <h3 className="text-3xl font-bold serif">Domestic Delivery (USA)</h3>
              <div className="space-y-6">
                <div className="flex justify-between border-b pb-4">
                  <span className="font-bold text-[11px] uppercase tracking-widest text-gray-400">Standard (3-5 Days)</span>
                  <span className="font-bold text-[12px]">$9.00 / FREE OVER $150</span>
                </div>
                <div className="flex justify-between border-b pb-4">
                  <span className="font-bold text-[11px] uppercase tracking-widest text-pink-600">Express (2 Days)</span>
                  <span className="font-bold text-[12px]">$15.00</span>
                </div>
                <div className="flex justify-between border-b pb-4">
                  <span className="font-bold text-[11px] uppercase tracking-widest text-gray-400">Overnight</span>
                  <span className="font-bold text-[12px]">$35.00</span>
                </div>
              </div>
              <p className="text-sm text-gray-500 italic">Orders placed before 2PM PST ship same-day.</p>
            </div>
            <div className="space-y-10">
              <h3 className="text-3xl font-bold serif">International Shipping</h3>
              <p className="text-gray-600 leading-relaxed">We ship to over 150 countries via DHL Express. International rates are calculated at checkout based on weight and destination.</p>
              <div className="bg-gray-50 p-8 rounded-sm space-y-4">
                <h5 className="font-bold uppercase text-[10px] tracking-widest">Global Rewards</h5>
                <p className="text-xs text-gray-500">Spend over $300 internationally for a flat $10 shipping rate anywhere in the world.</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    returns: {
      title: 'Returns & Exchanges',
      subtitle: 'Worry-free shopping at its finest.',
      hero: 'https://images.unsplash.com/photo-1556742044-3c52d6e88c62?auto=format&fit=crop&q=80&w=2070',
      body: (
        <div className="space-y-16">
          <section className="max-w-3xl space-y-8">
            <h3 className="text-4xl font-bold serif">30-Day Happiness Guarantee</h3>
            <p className="text-lg text-gray-600 font-light leading-relaxed">Not the perfect fit? We've got you. Our return process is fully digital and takes less than 2 minutes.</p>
          </section>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="p-10 border border-gray-100 space-y-6">
              <h4 className="text-xl font-bold uppercase tracking-tight">Easy Returns</h4>
              <ul className="space-y-4 text-sm text-gray-500 list-disc pl-4">
                <li>Returns must be initiated within 30 days of delivery.</li>
                <li>Items must be unworn, with original tags and packaging.</li>
                <li>Refunds are processed to the original payment method within 7-10 business days.</li>
              </ul>
            </div>
            <div className="p-10 border border-gray-100 bg-gray-50 space-y-6">
              <h4 className="text-xl font-bold uppercase tracking-tight">Rapid Exchanges</h4>
              <ul className="space-y-4 text-sm text-gray-500 list-disc pl-4">
                <li>Size exchanges are always 100% free.</li>
                <li>We ship the new size as soon as your return package is scanned by the carrier.</li>
                <li>No wait time, no stress.</li>
              </ul>
            </div>
          </div>
        </div>
      )
    },
    careers: {
      title: 'Join the Vibe',
      subtitle: 'Build the future of luxury commerce.',
      hero: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=2070',
      body: (
        <div className="space-y-20">
          <div className="max-w-3xl space-y-8">
            <h3 className="text-4xl font-bold serif">We're looking for trendsetters, technologists, and dreamers.</h3>
            <p className="text-lg text-gray-600 font-light">At LuxeVibe, we value creativity, autonomy, and a passion for redefining the digital experience. We operate remotely first, with hubs in Los Angeles and New York.</p>
          </div>

          <div className="space-y-12">
            <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-pink-600 border-b pb-4">Open Roles</h4>
            {[
              { role: 'Senior UX Designer', loc: 'Remote / Los Angeles' },
              { role: 'Fashion Merchandiser', loc: 'New York City' },
              { role: 'AI Engineering Lead', loc: 'Remote' },
              { role: 'Social Content Creator', loc: 'Los Angeles' }
            ].map(job => (
              <div key={job.role} className="flex justify-between items-center group cursor-pointer border-b border-gray-50 pb-8 hover:border-black transition duration-500">
                <div>
                  <h5 className="text-xl font-bold group-hover:text-pink-600 transition">{job.role}</h5>
                  <p className="text-[11px] text-gray-400 font-bold uppercase tracking-widest mt-1">{job.loc}</p>
                </div>
                <ArrowRight size={20} className="text-gray-200 group-hover:text-black group-hover:translate-x-2 transition-all" />
              </div>
            ))}
          </div>
        </div>
      )
    },
    privacy: {
      title: 'Privacy Policy',
      subtitle: 'How we protect your style and your data.',
      hero: '',
      body: (
        <div className="space-y-12 text-sm text-gray-600 leading-relaxed max-w-4xl">
          <section className="space-y-4">
             <h4 className="text-xl font-bold text-black serif">Introduction</h4>
             <p>This Privacy Policy describes how LuxeVibe ("we", "us", or "our") collects, uses, and shares your personal information when you visit or make a purchase from our website. We are committed to transparency and the protection of your digital footprint.</p>
          </section>
          <section className="space-y-4">
             <h4 className="text-xl font-bold text-black serif">Information We Collect</h4>
             <p>When you visit the Site, we automatically collect certain information about your device, including information about your web browser, IP address, time zone, and some of the cookies that are installed on your device. Additionally, as you browse the Site, we collect information about the individual web pages or products that you view, what websites or search terms referred you to the Site, and information about how you interact with the Site.</p>
          </section>
          <section className="space-y-4">
             <h4 className="text-xl font-bold text-black serif">How Do We Use Your Personal Information?</h4>
             <p>We use the Order Information that we collect generally to fulfill any orders placed through the Site (including processing your payment information, arranging for shipping, and providing you with invoices and/or order confirmations). Additionally, we use this Order Information to: Communicate with you; Screen our orders for potential risk or fraud; and When in line with the preferences you have shared with us, provide you with information or advertising relating to our products or services.</p>
          </section>
        </div>
      )
    },
    terms: {
      title: 'Terms of Service',
      subtitle: 'The legal vibe.',
      hero: '',
      body: (
        <div className="space-y-12 text-sm text-gray-600 leading-relaxed max-w-4xl">
           <section className="space-y-4">
             <h4 className="text-xl font-bold text-black serif">1. Overview</h4>
             <p>This website is operated by LuxeVibe. Throughout the site, the terms “we”, “us” and “our” refer to LuxeVibe. LuxeVibe offers this website, including all information, tools and services available from this site to you, the user, conditioned upon your acceptance of all terms, conditions, policies and notices stated here.</p>
          </section>
          <section className="space-y-4">
             <h4 className="text-xl font-bold text-black serif">2. Online Store Terms</h4>
             <p>By agreeing to these Terms of Service, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence and you have given us your consent to allow any of your minor dependents to use this site.</p>
          </section>
          <section className="space-y-4">
             <h4 className="text-xl font-bold text-black serif">3. Modifications to the Service and Prices</h4>
             <p>Prices for our products are subject to change without notice. We reserve the right at any time to modify or discontinue the Service (or any part or content thereof) without notice at any time.</p>
          </section>
        </div>
      )
    },
    faq: {
      title: 'FAQ',
      subtitle: 'Quick answers for curated minds.',
      hero: '',
      body: (
        <div className="space-y-8 max-w-4xl">
           {[
             { q: 'How do I know my size?', a: 'Every product page includes a detailed "Size & Fit" section with actual model measurements and fit notes. We also provide a comprehensive global size conversion chart.' },
             { q: 'Do you offer international shipping?', a: 'Yes! We ship to over 150 countries via DHL Express. Rates and transit times are calculated at checkout.' },
             { q: 'Can I cancel my order?', a: 'Orders move fast at LuxeVibe. You have a 30-minute window after placing an order to cancel it via your account dashboard or by contacting live support.' },
             { q: 'What payment methods do you accept?', a: 'We accept all major credit cards, PayPal, Afterpay, Klarna, and Apple Pay.' },
             { q: 'Is the AI Stylist free?', a: 'Absolutely. Our Trend Specialist is available 24/7 on every product page to help you curate the perfect look.' }
           ].map((faq, i) => (
             <div key={i} className="border-b border-gray-100 pb-8">
               <h4 className="text-lg font-bold serif mb-4">{faq.q}</h4>
               <p className="text-sm text-gray-500 leading-relaxed">{faq.a}</p>
             </div>
           ))}
        </div>
      )
    }
  };

  const activeContent = contentMap[type];

  return (
    <div className="pb-40">
      {/* Header */}
      <div className="bg-white border-b border-gray-50">
        <div className="max-w-[1400px] mx-auto px-4 py-16 md:py-24">
           <nav className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-8">
            <Link to="/" className="hover:text-black transition">Home</Link>
            <ChevronRight size={10} />
            <span className="text-black">{activeContent.title}</span>
          </nav>
          <h1 className="text-6xl md:text-8xl font-black serif tracking-tighter mb-6">{activeContent.title}</h1>
          <p className="text-xl md:text-2xl text-gray-400 font-light italic serif">{activeContent.subtitle}</p>
        </div>
      </div>

      {/* Hero Image */}
      {activeContent.hero && (
        <div className="max-w-[1400px] mx-auto px-4 -mt-10 mb-24">
          <div className="aspect-[21/9] w-full bg-gray-100 overflow-hidden shadow-2xl">
            <img src={activeContent.hero} className="w-full h-full object-cover" alt="" />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-[1400px] mx-auto px-4 flex flex-col lg:flex-row gap-20">
        {/* Sticky Secondary Nav */}
        <aside className="hidden lg:block w-64 shrink-0 h-fit sticky top-40 space-y-12">
           <div className="space-y-6">
              <h5 className="text-[10px] font-black uppercase tracking-[0.3em] text-pink-600">Explore</h5>
              <ul className="text-[11px] font-bold uppercase tracking-widest space-y-4 text-gray-400">
                <li><Link to="/our-story" className={`hover:text-black transition ${type === 'story' ? 'text-black' : ''}`}>Our Story</Link></li>
                <li><Link to="/sustainability" className={`hover:text-black transition ${type === 'sustainability' ? 'text-black' : ''}`}>Sustainability</Link></li>
                <li><Link to="/careers" className={`hover:text-black transition ${type === 'careers' ? 'text-black' : ''}`}>Careers</Link></li>
                <li><Link to="/shipping-info" className={`hover:text-black transition ${type === 'shipping' ? 'text-black' : ''}`}>Shipping</Link></li>
                <li><Link to="/returns-exchanges" className={`hover:text-black transition ${type === 'returns' ? 'text-black' : ''}`}>Returns</Link></li>
              </ul>
           </div>
           
           <div className="p-8 bg-gray-50 rounded-sm space-y-4">
              <h5 className="text-[10px] font-black uppercase tracking-[0.3em]">Need Help?</h5>
              <p className="text-[11px] text-gray-500 leading-relaxed font-medium">Our client advisors are available 24/7 via live chat.</p>
              <Link to="/contact-us" className="inline-block text-[10px] font-bold uppercase tracking-widest border-b border-black">Contact Us</Link>
           </div>
        </aside>

        {/* Dynamic Content Rendering */}
        <div className="flex-1 animate-in fade-in slide-in-from-bottom-4 duration-1000">
          {activeContent.body}
        </div>
      </div>
    </div>
  );
};

export default InfoPage;
