
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { CreditCard, Truck, CheckCircle, ChevronLeft, ShieldCheck, Gift, Tag, ChevronRight, Shield } from 'lucide-react';
import { CartItem, Address } from '../types';

interface CheckoutProps {
  cartItems: CartItem[];
  onClearCart: () => void;
}

const Checkout: React.FC<CheckoutProps> = ({ cartItems, onClearCart }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmation'>('shipping');
  const [promoCode, setPromoCode] = useState('');
  
  // Revolve Multi-Buy Logic
  const subtotal = cartItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const multiBuyDiscount = cartItems.length >= 2 ? subtotal * 0.15 : 0;
  const shipping = subtotal > 150 ? 0 : 15;
  const tax = (subtotal - multiBuyDiscount) * 0.0825;
  const total = subtotal - multiBuyDiscount + shipping + tax;

  const [address, setAddress] = useState<Address>({
    fullName: '',
    email: '',
    address: '',
    city: '',
    zipCode: '',
    country: 'United States'
  });

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAddress({ ...address, [e.target.name]: e.target.value });
  };

  const handlePlaceOrder = () => {
    setStep('confirmation');
    window.scrollTo(0, 0);
    setTimeout(() => {
      onClearCart();
      navigate('/');
    }, 8000);
  };

  if (cartItems.length === 0 && step !== 'confirmation') {
    return (
      <div className="max-w-[1400px] mx-auto px-4 py-40 text-center space-y-8">
        <h2 className="text-6xl font-black uppercase tracking-tighter text-black">Your bag is empty</h2>
        <p className="text-gray-400 uppercase tracking-widest text-xs font-bold">Trending pieces are waiting for you.</p>
        <Link to="/listing" className="inline-block bg-black text-white px-16 py-6 uppercase text-[10px] font-black tracking-[0.3em] hover:bg-pink-600 transition-all shadow-2xl">Return to Shop</Link>
      </div>
    );
  }

  if (step === 'confirmation') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-32 text-center animate-in fade-in zoom-in duration-700">
        <div className="inline-flex items-center justify-center w-24 h-24 bg-black text-white rounded-full mb-10 shadow-2xl">
          <CheckCircle size={48} />
        </div>
        <h1 className="text-5xl font-black mb-6 uppercase tracking-tighter">Order Success</h1>
        <p className="text-gray-500 mb-10 text-lg font-light leading-relaxed">Your curated order <span className="font-black text-black">#LV-2024-92841</span> is being prepared. Follow your style journey at <span className="font-bold text-black">{address.email}</span>.</p>
        
        <div className="bg-gray-50 p-12 text-left space-y-6 rounded-sm border border-gray-100 mb-12 shadow-inner">
           <h4 className="text-[10px] font-black uppercase tracking-widest text-pink-600">Arriving in 2 Days</h4>
           <p className="text-sm font-bold">{address.fullName}</p>
           <p className="text-sm text-gray-600">{address.address}, {address.city}, {address.zipCode}</p>
        </div>
        
        <button onClick={() => navigate('/')} className="text-[10px] font-black uppercase tracking-[0.4em] border-b-2 border-black pb-1 hover:text-pink-600 hover:border-pink-600 transition-all">Explore New Arrivals</button>
      </div>
    );
  }

  return (
    <div className="max-w-[1400px] mx-auto px-4 py-20">
      <div className="flex flex-col lg:flex-row gap-24">
        
        {/* Checkout Forms */}
        <div className="flex-1 space-y-20">
          <div className="flex items-center gap-8 border-b border-gray-50 pb-6">
            <span className={`text-[11px] font-black uppercase tracking-[0.3em] ${step === 'shipping' ? 'text-black' : 'text-gray-300'}`}>01 SHIPPING</span>
            <div className="w-12 h-[1px] bg-gray-100" />
            <span className={`text-[11px] font-black uppercase tracking-[0.3em] ${step === 'payment' ? 'text-black' : 'text-gray-300'}`}>02 PAYMENT</span>
          </div>

          {step === 'shipping' ? (
            <div className="space-y-12 animate-in slide-in-from-left">
              <div className="space-y-4">
                <h2 className="text-5xl font-black uppercase tracking-tighter">Shipping Info</h2>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Complimentary Express Shipping on all Boutique Orders</p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-10">
                <div className="col-span-2 space-y-3">
                  <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-500">Full Name</label>
                  <input name="fullName" value={address.fullName} onChange={handleAddressChange} className="w-full border-b-2 border-gray-100 py-4 outline-none focus:border-black transition-all uppercase text-[12px] font-bold tracking-widest" placeholder="YOUR NAME" />
                </div>
                <div className="col-span-2 space-y-3">
                  <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-500">Email Address</label>
                  <input name="email" value={address.email} onChange={handleAddressChange} className="w-full border-b-2 border-gray-100 py-4 outline-none focus:border-black transition-all uppercase text-[12px] font-bold tracking-widest" placeholder="EMAIL@EXAMPLE.COM" />
                </div>
                <div className="col-span-2 space-y-3">
                  <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-500">Address</label>
                  <input name="address" value={address.address} onChange={handleAddressChange} className="w-full border-b-2 border-gray-100 py-4 outline-none focus:border-black transition-all uppercase text-[12px] font-bold tracking-widest" placeholder="STREET ADDRESS" />
                </div>
                <div className="space-y-3">
                  <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-500">City</label>
                  <input name="city" value={address.city} onChange={handleAddressChange} className="w-full border-b-2 border-gray-100 py-4 outline-none focus:border-black transition-all uppercase text-[12px] font-bold tracking-widest" placeholder="CITY" />
                </div>
                <div className="space-y-3">
                  <label className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-500">Zip Code</label>
                  <input name="zipCode" value={address.zipCode} onChange={handleAddressChange} className="w-full border-b-2 border-gray-100 py-4 outline-none focus:border-black transition-all uppercase text-[12px] font-bold tracking-widest" placeholder="ZIP" />
                </div>
              </div>

              <button 
                onClick={() => setStep('payment')}
                disabled={!address.fullName || !address.email || !address.address}
                className="w-full py-7 bg-black text-white text-[10px] font-black uppercase tracking-[0.4em] disabled:bg-gray-100 disabled:text-gray-300 transition-all shadow-2xl hover:bg-pink-600"
              >
                Continue to Payment
              </button>
            </div>
          ) : (
            <div className="space-y-12 animate-in slide-in-from-right">
              <button onClick={() => setStep('shipping')} className="flex items-center gap-2 text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 hover:text-black">
                <ChevronLeft size={14} /> Edit Shipping
              </button>
              <div className="space-y-4">
                <h2 className="text-5xl font-black uppercase tracking-tighter">Payment Details</h2>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Encrypted Checkout Experience</p>
              </div>

              <div className="p-10 bg-black text-white space-y-10 rounded-sm shadow-2xl">
                  <div className="flex justify-between items-center border-b border-gray-800 pb-6">
                    <span className="text-[10px] font-black tracking-widest">SECURE CARD PAYMENT</span>
                    <Shield size={20} className="text-green-500" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[9px] font-black uppercase tracking-widest text-gray-500">Credit Card Number</label>
                    <input className="w-full bg-transparent border-b border-gray-800 py-4 outline-none focus:border-white transition-all tracking-[0.4em]" placeholder="•••• •••• •••• ••••" />
                  </div>
                  <div className="grid grid-cols-2 gap-10">
                    <div className="space-y-3">
                      <label className="text-[9px] font-black uppercase tracking-widest text-gray-500">Expiry</label>
                      <input className="w-full bg-transparent border-b border-gray-800 py-4 outline-none focus:border-white transition-all" placeholder="MM/YY" />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[9px] font-black uppercase tracking-widest text-gray-500">CVV</label>
                      <input className="w-full bg-transparent border-b border-gray-800 py-4 outline-none focus:border-white transition-all" placeholder="•••" />
                    </div>
                  </div>
              </div>

              <button 
                onClick={handlePlaceOrder}
                className="w-full py-7 bg-black text-white text-[10px] font-black uppercase tracking-[0.4em] hover:bg-pink-600 transition-all shadow-2xl"
              >
                Place Order — ${total.toFixed(2)}
              </button>
            </div>
          )}
        </div>

        {/* Order Summary Sidebar */}
        <div className="w-full lg:w-[480px]">
          <div className="bg-white border border-gray-100 p-12 sticky top-40 space-y-10 shadow-2xl rounded-sm">
            <h3 className="text-2xl font-black uppercase tracking-tight border-b border-gray-50 pb-6">Order Summary</h3>
            
            <div className="space-y-8 max-h-[350px] overflow-y-auto pr-4 scrollbar-hide">
              {cartItems.map((item, idx) => (
                <div key={idx} className="flex gap-6 group">
                  <div className="relative shrink-0 w-24 h-32">
                    <img src={item.product.images[0]} className="w-full h-full object-cover shadow-lg" alt="" />
                    <span className="absolute -top-2 -right-2 bg-black text-white text-[9px] font-black rounded-full w-6 h-6 flex items-center justify-center border-2 border-white">{item.quantity}</span>
                  </div>
                  <div className="flex-1 py-1 flex flex-col justify-between">
                    <div>
                      <p className="text-[9px] font-black uppercase tracking-widest text-pink-600 mb-1">{item.product.brand}</p>
                      <h4 className="text-[11px] font-bold uppercase leading-tight">{item.product.name}</h4>
                      <p className="text-[9px] text-gray-400 font-bold mt-2 uppercase tracking-widest">SIZE: {item.selectedSize}</p>
                    </div>
                    <p className="text-sm font-black tracking-tight">${item.product.price}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-6 pt-10 border-t border-gray-50 font-bold uppercase tracking-widest text-[10px]">
              <div className="flex justify-between">
                <span className="text-gray-400">Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              
              {multiBuyDiscount > 0 && (
                <div className="flex justify-between text-pink-600">
                  <span className="flex items-center gap-2"><Tag size={12}/> Multi-Buy Savings (15%)</span>
                  <span>-${multiBuyDiscount.toFixed(2)}</span>
                </div>
              )}
              
              <div className="flex justify-between">
                <span className="text-gray-400">Express Shipping</span>
                <span className={shipping === 0 ? 'text-green-600' : ''}>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Estimated Tax</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-2xl font-black pt-8 border-t border-gray-100 tracking-tighter">
                <span className="serif uppercase text-lg">Order Total</span>
                <span className="text-pink-600">${total.toFixed(2)}</span>
              </div>
            </div>
            
            <p className="text-[9px] text-gray-300 font-bold uppercase tracking-widest text-center italic">Securely processed by LuxeVibe Boutique</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
