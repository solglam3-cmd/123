
import React, { useMemo, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import QuickViewModal from '../components/QuickViewModal';
import { PRODUCTS, CATEGORIES } from '../constants';
import { Product, CartItem } from '../types';
import { ChevronDown, SlidersHorizontal, X, ChevronRight } from 'lucide-react';

interface ProductListingProps {
  onAddToCart: (item: CartItem) => void;
}

const ProductListing: React.FC<ProductListingProps> = ({ onAddToCart }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const activeCat = searchParams.get('cat') || 'All';

  const filteredProducts = useMemo(() => {
    let result = PRODUCTS;
    if (activeCat === 'Sale') return result.filter(p => p.isSale);
    if (activeCat !== 'All') return result.filter(p => p.category === activeCat);
    return result;
  }, [activeCat]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-12 border-b border-gray-50 pb-4">
        <Link to="/" className="hover:text-black transition">Home</Link>
        <ChevronRight size={10} />
        <span className="text-black">SHOP ALL {activeCat.toUpperCase()}</span>
      </nav>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-20">
        <div className="space-y-4">
          <h1 className="text-7xl font-bold serif leading-none tracking-tight">{activeCat}</h1>
          <p className="text-gray-400 text-[11px] font-bold uppercase tracking-[0.3em]">{filteredProducts.length} DESIGNS AVAILABLE</p>
        </div>
        
        {/* Horizontal Category Pill Filter */}
        <div className="flex items-center gap-4 overflow-x-auto pb-4 scrollbar-hide md:pb-0">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSearchParams({ cat })}
              className={`whitespace-nowrap px-10 py-4 text-[10px] uppercase font-bold tracking-widest transition-all rounded-full border ${activeCat === cat ? 'bg-black text-white border-black shadow-xl scale-105' : 'bg-white text-gray-500 border-gray-100 hover:border-black'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-20">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block w-72 space-y-16 sticky top-44 h-fit pr-10 border-r border-gray-50">
          <div className="space-y-8">
            <h4 className="font-bold text-[11px] uppercase tracking-[0.2em] flex items-center justify-between group cursor-pointer">
              Filter By Size <ChevronDown size={14} className="text-gray-300 group-hover:text-black transition" />
            </h4>
            <div className="grid grid-cols-4 gap-2">
              {['XXS', 'XS', 'S', 'M', 'L', 'XL', '24', '25', '26', '27', '28'].map(s => (
                <button key={s} className="border border-gray-100 aspect-square flex items-center justify-center text-[10px] font-bold hover:border-black hover:bg-black hover:text-white transition-all shadow-sm">{s}</button>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <h4 className="font-bold text-[11px] uppercase tracking-[0.2em] flex items-center justify-between group cursor-pointer">
              Occasion <ChevronDown size={14} className="text-gray-300" />
            </h4>
            <div className="space-y-4">
              {['Cocktail', 'Night Out', 'Work', 'Vacation', 'Brunch'].map(m => (
                <label key={m} className="flex items-center gap-3 cursor-pointer group">
                  <div className="w-5 h-5 border border-gray-200 group-hover:border-black transition-colors flex items-center justify-center">
                    {/* Simulated Check */}
                  </div>
                  <span className="text-[11px] font-bold text-gray-400 group-hover:text-black transition uppercase tracking-widest">{m}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <h4 className="font-bold text-[11px] uppercase tracking-[0.2em] flex items-center justify-between group cursor-pointer">
              Color Family <ChevronDown size={14} className="text-gray-300" />
            </h4>
            <div className="flex flex-wrap gap-4">
              {['black', 'white', 'beige', 'blue', 'pink', 'red'].map(color => (
                <button key={color} className={`w-8 h-8 rounded-full border border-gray-100 shadow-inner hover:scale-125 transition duration-300`} style={{ backgroundColor: color }} />
              ))}
            </div>
          </div>

          <div className="pt-10 border-t border-gray-50">
            <div className="bg-black text-white p-8 space-y-5 rounded-sm">
              <h5 className="text-[10px] font-bold uppercase tracking-[0.3em] text-pink-400">Vibe Rewards</h5>
              <p className="text-[11px] text-gray-400 leading-relaxed font-medium">Join our loyalty program and earn 20 points for every $1 spent today.</p>
              <button className="text-[10px] font-bold uppercase tracking-widest underline underline-offset-4 decoration-pink-600">Learn More</button>
            </div>
          </div>
        </aside>

        {/* Product Grid Area */}
        <div className="flex-1">
          {/* Active Filters Display */}
          <div className="flex flex-wrap items-center gap-4 mb-12">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-300">CURATED SELECTION:</span>
            {activeCat !== 'All' && (
              <button 
                onClick={() => setSearchParams({ cat: 'All' })}
                className="flex items-center gap-2 bg-gray-50 px-6 py-3 text-[10px] font-bold uppercase tracking-widest rounded-full group hover:bg-black hover:text-white transition shadow-sm"
              >
                {activeCat} <X size={12} className="group-hover:rotate-180 transition-transform" />
              </button>
            )}
            <button className="text-[10px] font-bold uppercase tracking-widest underline decoration-gray-200 text-gray-400 hover:text-black ml-auto">Reset Gallery</button>
          </div>

          {/* Sort & Mobile Filter Toggle */}
          <div className="flex justify-between items-center mb-16 border-b border-gray-100 pb-8">
            <button className="lg:hidden flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest border border-gray-200 px-8 py-4">
              <SlidersHorizontal size={14} /> FILTER & SORT
            </button>
            <div className="flex items-center gap-6 text-[11px] font-bold uppercase tracking-widest ml-auto">
              <span className="text-gray-300">ORDER BY:</span>
              <button className="flex items-center gap-2 group hover:text-pink-600 transition">BEST SELLERS <ChevronDown size={14} className="text-gray-200 group-hover:text-pink-600 transition" /></button>
            </div>
          </div>

          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-12 gap-y-24 animate-in fade-in duration-1000">
              {filteredProducts.map(product => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onQuickView={() => setQuickViewProduct(product)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-48 bg-gray-50">
              <p className="text-gray-300 serif italic text-3xl mb-8">Refining our vault for your aesthetic...</p>
              <button onClick={() => setSearchParams({ cat: 'All' })} className="text-[11px] font-bold uppercase tracking-[0.4em] bg-black text-white px-12 py-5 shadow-2xl hover:bg-pink-600 transition-colors">Return to All Designs</button>
            </div>
          )}

          {/* Pagination */}
          <div className="mt-40 pt-16 border-t border-gray-100 flex flex-col items-center space-y-8">
            <p className="text-[11px] font-bold uppercase tracking-[0.3em] text-gray-300">EXPLORING PAGE 1 OF 12</p>
            <div className="flex items-center gap-4">
              <button className="w-12 h-12 flex items-center justify-center bg-black text-white font-bold text-xs shadow-xl scale-110">1</button>
              <button className="w-12 h-12 flex items-center justify-center border border-gray-100 hover:border-black transition font-bold text-xs">2</button>
              <button className="w-12 h-12 flex items-center justify-center border border-gray-100 hover:border-black transition font-bold text-xs">3</button>
              <span className="px-4 text-gray-200">...</span>
              <button className="w-12 h-12 flex items-center justify-center border border-gray-100 hover:border-black transition font-bold text-xs">12</button>
            </div>
          </div>
        </div>
      </div>

      <QuickViewModal 
        product={quickViewProduct} 
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={onAddToCart}
      />
    </div>
  );
};

export default ProductListing;
