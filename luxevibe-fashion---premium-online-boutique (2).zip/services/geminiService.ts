
import { GoogleGenAI } from "@google/genai";

// Fixed: Initialized GoogleGenAI using process.env.API_KEY directly as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getStylingAdvice = async (productName: string, category: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide 3 short, stylish outfit pairing tips for a ${productName} in the ${category} category. Keep it professional, trendy, and concise (max 50 words per tip).`,
      config: {
        temperature: 0.7,
        // Fixed: Removed maxOutputTokens to avoid reaching limit or requiring thinkingBudget config
      }
    });
    // Fixed: Accessed text property directly (not as a method)
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Our AI Stylist is busy at a fashion show. Check back later for personalized tips!";
  }
};
