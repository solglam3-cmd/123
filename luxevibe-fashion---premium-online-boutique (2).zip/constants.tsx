
import { Product, Review } from './types';

export const CATEGORIES = ['All', 'Dresses', 'Tops', 'Bottoms', 'Accessories', 'Shoes', 'Sale'];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Silk Slip Midi Dress',
    brand: 'NBD',
    price: 198,
    category: 'Dresses',
    description: 'A timeless silhouette crafted from 100% heavy-weight silk. Featuring adjustable spaghetti straps and a subtle side slit.',
    images: [
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: ['XXS', 'XS', 'S', 'M', 'L'],
    colors: ['Champagne', 'Midnight', 'Emerald'],
    rating: 4.8,
    reviewsCount: 124,
    isNew: true,
    material: '100% Silk',
    care: 'Dry clean only',
    modelInfo: 'Model is wearing size S',
    modelSpecs: { height: "5'10\"", waist: '24"', bust: '32"', hips: '34"' },
    fitNotes: 'Runs true to size. Relaxed fit through the hips.',
    completeLookIds: ['5', '6'],
    style: 'Classic',
    occasion: 'Cocktail'
  },
  {
    id: '2',
    name: 'High-Rise Straight Leg Jean',
    brand: 'AGOLDE',
    price: 188,
    originalPrice: 228,
    category: 'Bottoms',
    description: 'The ultimate vintage-inspired fit. Classic straight leg with a flattering high rise in a worn-in indigo wash.',
    images: [
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1604176354204-9268737828e4?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: ['24', '25', '26', '27', '28', '29', '30'],
    colors: ['Vintage Blue', 'Black'],
    rating: 4.5,
    reviewsCount: 89,
    isSale: true,
    material: '98% Cotton, 2% Elastane',
    care: 'Machine wash cold inside out',
    modelInfo: 'Model is wearing size 26',
    modelSpecs: { height: "5'9\"", waist: '25"', bust: '33"', hips: '35"' },
    fitNotes: 'Structured denim with slight stretch. Sits at natural waist.',
    completeLookIds: ['3'],
    style: 'Vintage',
    occasion: 'Casual'
  },
  {
    id: '3',
    name: 'Oversized Cashmere Sweater',
    brand: 'LPA',
    price: 245,
    category: 'Tops',
    description: 'Luxuriously soft Mongolian cashmere. Boxy fit with dropped shoulders and ribbed trims.',
    images: [
      'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1574167132742-17fdb190b402?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: ['XS/S', 'M/L'],
    colors: ['Oatmeal', 'Camel', 'Grey'],
    rating: 4.9,
    reviewsCount: 56,
    material: '100% Mongolian Cashmere',
    care: 'Hand wash cold or dry clean',
    modelInfo: 'Model is wearing size M/L',
    modelSpecs: { height: "5'11\"", waist: '26"', bust: '34"', hips: '36"' },
    fitNotes: 'Intentionally oversized. Size down for a closer fit.',
    style: 'Modern',
    occasion: 'Work'
  },
  {
    id: '4',
    name: 'Vegan Leather Mini Skirt',
    brand: 'MAJORELLE',
    price: 148,
    category: 'Bottoms',
    description: 'Edgy meets chic. High-waisted mini skirt with exposed zip closure and buttery soft faux leather finish.',
    images: [
      'https://images.unsplash.com/photo-1582142839970-2b9e04b60f65?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Black', 'Burgundy'],
    rating: 4.2,
    reviewsCount: 34,
    isNew: true,
    material: 'Polyurethane Blend (Vegan)',
    care: 'Wipe clean with damp cloth',
    modelInfo: 'Model is wearing size XS',
    modelSpecs: { height: "5'8\"", waist: '23"', bust: '31"', hips: '33"' },
    fitNotes: 'Fitted through waist and hips.',
    style: 'Edgy',
    occasion: 'Night Out'
  },
  {
    id: '5',
    name: 'Pointed Toe Leather Mule',
    brand: 'RAYE',
    price: 165,
    category: 'Shoes',
    description: 'Elegant slip-on design with a kitten heel. Genuine leather upper and cushioned footbed.',
    images: [
      'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1535043934128-cf0b28d52f95?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: ['6', '7', '8', '9', '10'],
    colors: ['Nude', 'Tan'],
    rating: 4.7,
    reviewsCount: 42,
    material: '100% Bovine Leather',
    care: 'Leather conditioner recommended',
    fitNotes: 'Narrow fit. We recommend sizing up half a size.',
    style: 'Elegant',
    occasion: 'Formal'
  },
  {
    id: '6',
    name: 'Crystal Hoop Earrings',
    brand: '8 Other Reasons',
    price: 48,
    originalPrice: 75,
    category: 'Accessories',
    description: 'Statement hoops that catch every light. Gold-plated with handset cubic zirconia crystals.',
    images: [
      'https://images.unsplash.com/photo-1635767798638-3e25273a8236?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1630019017592-0bf3a0c20560?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: ['One Size'],
    colors: ['Gold', 'Silver'],
    rating: 4.6,
    reviewsCount: 112,
    isSale: true,
    material: '14k Gold Plated Brass, CZ Crystals',
    style: 'Glam',
    occasion: 'Event'
  }
];

export const MOCK_REVIEWS: Review[] = [
  {
    id: 'r1',
    userName: 'Jessica M.',
    rating: 5,
    comment: 'Absolutely stunning! The fit is perfect and the quality is exactly what I expected from this brand. I wore it to a wedding and got so many compliments!',
    date: '2023-10-15',
    verified: true,
    sizePurchased: 'S',
    userHeight: "5'7\"",
    userWeight: '135 lbs'
  },
  {
    id: 'r2',
    userName: 'Sarah K.',
    rating: 4,
    comment: 'Very cute but runs a little small. I recommend sizing up if you are between sizes. The material is very high quality though.',
    date: '2023-11-02',
    verified: true,
    sizePurchased: 'M',
    userHeight: "5'5\"",
    userWeight: '145 lbs'
  }
];
