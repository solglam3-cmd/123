
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import Navbar from './components/Navbar';
import CartSidebar from './components/CartSidebar';
import Home from './pages/Home';
import ProductListing from './pages/ProductListing';
import ProductDetail from './pages/ProductDetail';
import Checkout from './pages/Checkout';
import InfoPage from './pages/InfoPage';
import ContactPage from './pages/ContactPage';
import TrackOrderPage from './pages/TrackOrderPage';
import { CartItem } from './types';

const App: React.FC = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const addToCart = (item: CartItem) => {
    setCartItems(prev => [...prev, item]);
    setIsCartOpen(true);
  };

  const removeFromCart = (index: number) => {
    setCartItems(prev => prev.filter((_, i) => i !== index));
  };

  const clearCart = () => setCartItems([]);

  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar 
          cartCount={cartItems.length} 
          onOpenCart={() => setIsCartOpen(true)} 
        />
        
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/listing" element={<ProductListing onAddToCart={addToCart} />} />
            <Route 
              path="/product/:id" 
              element={<ProductDetail onAddToCart={addToCart} />} 
            />
            <Route 
              path="/checkout" 
              element={<Checkout cartItems={cartItems} onClearCart={clearCart} />} 
            />
            
            {/* Customer Care Routes */}
            <Route path="/track-order" element={<TrackOrderPage />} />
            <Route path="/shipping-info" element={<InfoPage type="shipping" />} />
            <Route path="/returns-exchanges" element={<InfoPage type="returns" />} />
            <Route path="/contact-us" element={<ContactPage />} />
            <Route path="/faq" element={<InfoPage type="faq" />} />

            {/* About LuxeVibe Routes */}
            <Route path="/our-story" element={<InfoPage type="story" />} />
            <Route path="/sustainability" element={<InfoPage type="sustainability" />} />
            <Route path="/careers" element={<InfoPage type="careers" />} />
            <Route path="/privacy-policy" element={<InfoPage type="privacy" />} />
            <Route path="/terms-of-service" element={<InfoPage type="terms" />} />

            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>

        <footer className="bg-gray-950 text-white py-24 px-4 md:px-8 mt-auto border-t border-white/5">
          <div className="max-w-[1400px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-16 lg:gap-24">
            <div className="space-y-8">
              <h2 className="text-3xl font-bold tracking-tighter uppercase serif">Luxe<span className="font-light">Vibe</span></h2>
              <p className="text-gray-400 text-[13px] leading-relaxed font-light">The ultimate destination for luxury fashion, beauty, and lifestyle. Curated for the modern tastemaker in Los Angeles and beyond.</p>
              <div className="flex gap-6">
                {['Ig', 'Fb', 'Tw', 'Yt'].map(soc => (
                  <div key={soc} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition duration-500 cursor-pointer text-[10px] font-bold uppercase">{soc}</div>
                ))}
              </div>
            </div>
            
            <div className="space-y-6">
              <h4 className="text-[11px] font-bold uppercase tracking-[0.3em] text-pink-600">Customer Care</h4>
              <ul className="text-[13px] text-gray-400 space-y-4 font-light">
                <li className="hover:text-white transition"><Link to="/track-order">Track Your Order</Link></li>
                <li className="hover:text-white transition"><Link to="/shipping-info">Shipping Info</Link></li>
                <li className="hover:text-white transition"><Link to="/returns-exchanges">Returns & Exchanges</Link></li>
                <li className="hover:text-white transition"><Link to="/contact-us">Contact Us</Link></li>
                <li className="hover:text-white transition"><Link to="/faq">FAQ</Link></li>
              </ul>
            </div>

            <div className="space-y-6">
              <h4 className="text-[11px] font-bold uppercase tracking-[0.3em] text-pink-600">About LuxeVibe</h4>
              <ul className="text-[13px] text-gray-400 space-y-4 font-light">
                <li className="hover:text-white transition"><Link to="/our-story">Our Story</Link></li>
                <li className="hover:text-white transition"><Link to="/sustainability">Sustainability</Link></li>
                <li className="hover:text-white transition"><Link to="/careers">Careers</Link></li>
                <li className="hover:text-white transition"><Link to="/privacy-policy">Privacy Policy</Link></li>
                <li className="hover:text-white transition"><Link to="/terms-of-service">Terms of Service</Link></li>
              </ul>
            </div>

            <div className="space-y-8">
              <h4 className="text-[11px] font-bold uppercase tracking-[0.3em] text-pink-600">Join the Vibe</h4>
              <p className="text-[12px] text-gray-400 font-light leading-relaxed">Subscribe to receive 15% off your first order and exclusive access to new arrivals.</p>
              <div className="space-y-4">
                <div className="flex border-b border-white/20 pb-2">
                  <input 
                    type="email" 
                    placeholder="ENTER YOUR EMAIL" 
                    className="bg-transparent border-none outline-none text-[11px] flex-1 focus:ring-0 placeholder:text-gray-600 tracking-widest"
                  />
                  <button className="text-[10px] font-bold uppercase tracking-widest hover:text-pink-600 transition">Subscribe</button>
                </div>
                <p className="text-[9px] text-gray-500 font-medium uppercase tracking-widest">By signing up, you agree to our terms.</p>
              </div>
            </div>
          </div>
          <div className="max-w-[1400px] mx-auto border-t border-white/5 mt-24 pt-12 flex flex-col md:flex-row justify-between items-center gap-8">
            <p className="text-[10px] text-gray-500 uppercase tracking-[0.2em]">&copy; 2024 LuxeVibe Fashion. All Rights Reserved.</p>
            <div className="flex gap-8 text-[9px] text-gray-500 font-bold uppercase tracking-widest">
              <Link to="/privacy-policy" className="hover:text-white transition">Privacy</Link>
              <Link to="/terms-of-service" className="hover:text-white transition">Terms</Link>
              <span className="text-gray-700">Ad Choices</span>
            </div>
          </div>
        </footer>

        <CartSidebar 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          items={cartItems}
          onRemove={removeFromCart}
        />
      </div>
    </Router>
  );
};

export default App;
