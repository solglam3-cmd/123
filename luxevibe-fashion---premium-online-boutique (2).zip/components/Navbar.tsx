
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Search, Menu, X, User, ChevronDown, Tag } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ cartCount, onOpenCart }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [promoIndex, setPromoIndex] = useState(0);
  const promos = [
    "FREE 2-DAY SHIPPING & RETURNS",
    "BUY 2+ ITEMS, GET 15% OFF - APPLIED AT BAG",
    "NEW DESIGNERS JUST DROPPED",
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setPromoIndex((prev) => (prev + 1) % promos.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="sticky top-0 z-50">
      {/* Revolve Bold Promo Bar */}
      <div className="bg-black text-white text-[10px] font-bold py-2.5 overflow-hidden text-center tracking-[0.2em] relative flex items-center justify-center gap-2">
        <Tag size={12} className="text-pink-500" />
        <div key={promoIndex} className="animate-in fade-in slide-in-from-top-4 duration-500">
          {promos[promoIndex]}
        </div>
      </div>

      <nav className="bg-white border-b border-gray-100 px-4 md:px-8 py-4">
        <div className="max-w-[1400px] mx-auto flex items-center justify-between">
          {/* Left: Desktop Nav Items */}
          <div className="hidden lg:flex items-center space-x-8 text-[11px] font-bold uppercase tracking-[0.2em]">
            <Link to="/listing?cat=Dresses" className="hover:text-pink-600 transition">Dresses</Link>
            <Link to="/listing?cat=Tops" className="hover:text-pink-600 transition">Tops</Link>
            <Link to="/listing?cat=Sale" className="text-red-600 hover:text-red-700 font-black">Sale</Link>
          </div>

          {/* Center: Logo */}
          <div className="flex items-center">
            <button className="lg:hidden mr-4" onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <Link to="/" className="text-4xl font-bold tracking-tighter uppercase serif text-black">
              Luxe<span className="font-light">Vibe</span>
            </Link>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center space-x-6">
            <div className="hidden md:flex items-center border-b border-gray-100 px-2 py-1 text-xs">
              <input type="text" placeholder="Search brands..." className="bg-transparent border-none focus:ring-0 w-32 outline-none uppercase text-[10px] font-bold tracking-widest" />
              <Search size={14} className="text-gray-400" />
            </div>
            <Link to="/account" className="hidden sm:block text-gray-700 hover:text-pink-600">
              <User size={18} />
            </Link>
            <button onClick={onOpenCart} className="relative text-gray-700 hover:text-pink-600 group">
              <ShoppingBag size={20} />
              <span className="absolute -top-2 -right-2 bg-pink-600 text-white text-[8px] font-bold rounded-full w-4 h-4 flex items-center justify-center group-hover:scale-125 transition-transform">
                {cartCount}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="lg:hidden absolute top-full left-0 w-full bg-white border-b border-gray-200 p-8 flex flex-col space-y-6 text-xs font-bold uppercase tracking-[0.2em] shadow-2xl animate-in slide-in-from-top">
            <Link to="/listing?cat=Dresses" onClick={() => setIsOpen(false)}>Dresses</Link>
            <Link to="/listing?cat=Tops" onClick={() => setIsOpen(false)}>Tops</Link>
            <Link to="/listing?cat=Bottoms" onClick={() => setIsOpen(false)}>Bottoms</Link>
            <Link to="/listing?cat=Sale" className="text-red-600">Sale</Link>
            <div className="pt-6 border-t border-gray-100 flex gap-4">
              <Link to="/account" className="flex items-center gap-2"> <User size={16}/> Account</Link>
            </div>
          </div>
        )}
      </nav>
    </div>
  );
};

export default Navbar;
