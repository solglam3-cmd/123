
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Plus, Eye } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onQuickView?: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="group relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-[3/4] bg-gray-100 overflow-hidden">
        <Link to={`/product/${product.id}`}>
          <img 
            src={isHovered && product.images[1] ? product.images[1] : product.images[0]} 
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
          />
        </Link>
        
        {product.isNew && (
          <span className="absolute top-3 left-3 bg-black text-white text-[9px] font-bold uppercase tracking-[0.2em] px-2 py-1">New</span>
        )}
        {product.isSale && (
          <span className="absolute top-3 left-3 bg-red-600 text-white text-[9px] font-bold uppercase tracking-[0.2em] px-2 py-1">Sale</span>
        )}

        <button className="absolute top-3 right-3 p-1.5 bg-white rounded-full opacity-0 group-hover:opacity-100 transition shadow-sm hover:text-pink-500">
          <Heart size={16} />
        </button>

        {/* Quick View Button */}
        {onQuickView && (
          <button 
            onClick={(e) => {
              e.preventDefault();
              onQuickView();
            }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white/90 backdrop-blur-sm text-[10px] font-bold uppercase tracking-[0.2em] px-6 py-3 opacity-0 group-hover:opacity-100 transition-all hover:bg-black hover:text-white"
          >
            Quick View
          </button>
        )}

        {/* Quick Add Size Drawer */}
        <div className={`absolute bottom-0 left-0 w-full bg-white/95 backdrop-blur-sm p-3 transition-transform duration-300 translate-y-full group-hover:translate-y-0`}>
          <div className="flex justify-between items-center mb-2">
            <span className="text-[9px] font-bold uppercase tracking-widest text-gray-500">Quick Add</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {product.sizes.map((size) => (
              <button 
                key={size}
                className="text-[9px] font-bold border border-gray-200 px-2 py-1.5 hover:bg-black hover:text-white hover:border-black transition"
              >
                {size}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-4 px-1">
        <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500 mb-1">{product.brand}</p>
        <Link to={`/product/${product.id}`}>
          <h3 className="text-[11px] font-medium truncate group-hover:text-pink-600 transition-colors uppercase tracking-tight">{product.name}</h3>
        </Link>
        <div className="mt-2 flex items-center gap-2">
          <span className={`text-xs font-bold ${product.isSale ? 'text-red-600' : 'text-gray-900'}`}>
            ${product.price}
          </span>
          {product.originalPrice && (
            <span className="text-[10px] text-gray-400 line-through">${product.originalPrice}</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
