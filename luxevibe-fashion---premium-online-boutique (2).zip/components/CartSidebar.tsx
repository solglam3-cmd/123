
import React from 'react';
/* Added ShoppingBag and Tag to the imports */
import { X, Trash2, ChevronRight, Truck, Info, ShoppingBag, Tag } from 'lucide-react';
import { CartItem } from '../types';
import { Link } from 'react-router-dom';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemove: (index: number) => void;
}

const CartSidebar: React.FC<CartSidebarProps> = ({ isOpen, onClose, items, onRemove }) => {
  const subtotal = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  
  // Multi-buy Discount Logic
  const hasDiscount = items.length >= 2;
  const discountAmount = hasDiscount ? subtotal * 0.15 : 0;
  const total = subtotal - discountAmount;

  // Shipping Progress
  const freeShippingThreshold = 150;
  const shippingProgress = Math.min((subtotal / freeShippingThreshold) * 100, 100);
  const remainingForFree = Math.max(freeShippingThreshold - subtotal, 0);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex justify-end">
      <div className="absolute inset-0 bg-black bg-opacity-40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
        
        {/* Progress Bar Area */}
        <div className="bg-gray-50 p-6 border-b border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Truck size={16} className="text-pink-600" />
              <span className="text-[10px] font-bold uppercase tracking-widest">
                {subtotal >= freeShippingThreshold ? 'FREE SHIPPING UNLOCKED!' : `SPEND $${remainingForFree.toFixed(0)} MORE FOR FREE SHIPPING`}
              </span>
            </div>
            <button onClick={onClose}><X size={20} /></button>
          </div>
          <div className="w-full h-1 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-pink-600 transition-all duration-1000" 
              style={{ width: `${shippingProgress}%` }}
            />
          </div>
        </div>

        <div className="p-6 border-b">
          <h2 className="text-xl font-bold serif uppercase tracking-tight">Your Bag ({items.length})</h2>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8 scrollbar-hide">
          {items.length === 0 ? (
            <div className="text-center py-20 flex flex-col items-center">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-6 text-gray-300">
                <ShoppingBag size={24} />
              </div>
              <p className="text-gray-400 text-xs font-bold uppercase tracking-widest">Your bag is currently empty.</p>
              <button onClick={onClose} className="mt-8 bg-black text-white px-10 py-4 text-[10px] font-bold uppercase tracking-widest hover:bg-pink-600 transition">Shop Best Sellers</button>
            </div>
          ) : (
            items.map((item, idx) => (
              <div key={`${item.product.id}-${idx}`} className="flex gap-6 group animate-in slide-in-from-bottom-2">
                <div className="w-24 h-32 shrink-0 bg-gray-50 overflow-hidden">
                  <img src={item.product.images[0]} alt={item.product.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-700" />
                </div>
                <div className="flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-1">
                    <p className="text-[9px] font-bold uppercase tracking-widest text-pink-600">{item.product.brand}</p>
                    <button onClick={() => onRemove(idx)} className="text-gray-200 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                  </div>
                  <h4 className="text-[11px] font-bold uppercase tracking-tight mb-2 leading-snug">{item.product.name}</h4>
                  <div className="space-y-1">
                    <p className="text-[9px] text-gray-400 uppercase font-bold tracking-widest">Size: <span className="text-black">{item.selectedSize}</span></p>
                    <p className="text-[9px] text-gray-400 uppercase font-bold tracking-widest">Color: <span className="text-black">{item.selectedColor}</span></p>
                  </div>
                  <p className="mt-auto text-sm font-bold tracking-tight">${item.product.price}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {items.length > 0 && (
          <div className="p-8 border-t space-y-6 shadow-up">
            {hasDiscount && (
              <div className="bg-pink-50 text-pink-700 p-4 flex items-center justify-between text-[10px] font-bold uppercase tracking-widest">
                <span className="flex items-center gap-2"><Tag size={12}/> Multi-Buy Savings (15%)</span>
                <span>-${discountAmount.toFixed(2)}</span>
              </div>
            )}
            
            <div className="space-y-3">
              <div className="flex justify-between text-[11px] font-bold uppercase tracking-[0.2em] text-gray-400">
                <span>Subtotal</span>
                <span className="text-black">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-xl font-bold border-t border-gray-100 pt-4">
                <span className="serif uppercase tracking-tight">Total</span>
                <span className="tracking-tight text-pink-600">${total.toFixed(2)}</span>
              </div>
            </div>

            <Link 
              to="/checkout" 
              onClick={onClose}
              className="w-full bg-black text-white py-6 flex items-center justify-center gap-3 font-bold uppercase text-[10px] tracking-[0.3em] hover:bg-pink-600 transition shadow-2xl"
            >
              Secure Checkout <ChevronRight size={14} />
            </Link>
            
            <p className="text-[9px] text-gray-300 uppercase font-bold tracking-widest text-center flex items-center justify-center gap-2">
              <Info size={10} /> Afterpay & Klarna available
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartSidebar;
