
import React, { useState } from 'react';
import { X, Star, ArrowRight } from 'lucide-react';
import { Product, CartItem } from '../types';
import { Link } from 'react-router-dom';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
}

const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose, onAddToCart }) => {
  if (!product) return null;

  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);

  const handleAddToCart = () => {
    if (!selectedSize) return;
    onAddToCart({
      product,
      quantity: 1,
      selectedSize,
      selectedColor,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl animate-in zoom-in-95 duration-300">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X size={20} />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left: Image */}
          <div className="aspect-[3/4] bg-gray-50">
            <img 
              src={product.images[0]} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Right: Details */}
          <div className="p-8 md:p-12 flex flex-col">
            <div className="mb-6">
              <p className="text-[11px] font-bold uppercase tracking-[0.3em] text-pink-600 mb-2">{product.brand}</p>
              <h2 className="text-3xl font-bold serif mb-4">{product.name}</h2>
              <div className="flex items-center gap-4">
                <span className="text-2xl font-bold">${product.price}</span>
                {product.originalPrice && (
                  <span className="text-lg text-gray-400 line-through">${product.originalPrice}</span>
                )}
              </div>
            </div>

            <p className="text-sm text-gray-600 leading-relaxed mb-8 line-clamp-3">
              {product.description}
            </p>

            <div className="space-y-6 mb-10">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-3">Select Size</p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map(size => (
                    <button 
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-[3rem] h-10 text-[10px] font-bold uppercase border transition-all ${
                        selectedSize === size 
                          ? 'bg-black text-white border-black shadow-lg' 
                          : 'bg-white border-gray-200 hover:border-black'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-auto space-y-4">
              <button 
                onClick={handleAddToCart}
                disabled={!selectedSize}
                className={`w-full py-5 text-[11px] font-bold uppercase tracking-[0.3em] transition-all ${
                  selectedSize 
                    ? 'bg-black text-white hover:bg-gray-800 shadow-xl' 
                    : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                }`}
              >
                {selectedSize ? 'Add to Bag' : 'Select a Size'}
              </button>
              
              <Link 
                to={`/product/${product.id}`}
                onClick={onClose}
                className="flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-black transition-colors py-2"
              >
                View Full Details <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickViewModal;
