
export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  category: string;
  description: string;
  images: string[];
  sizes: string[];
  colors: string[];
  rating: number;
  reviewsCount: number;
  isNew?: boolean;
  isSale?: boolean;
  material?: string;
  care?: string;
  modelInfo?: string;
  modelSpecs?: {
    height: string;
    waist: string;
    bust: string;
    hips: string;
  };
  fitNotes?: string;
  completeLookIds?: string[];
  style?: string;
  occasion?: string;
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
  sizePurchased?: string;
  userHeight?: string;
  userWeight?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize: string;
  selectedColor: string;
}

export interface Address {
  fullName: string;
  email: string;
  address: string;
  city: string;
  zipCode: string;
  country: string;
}
